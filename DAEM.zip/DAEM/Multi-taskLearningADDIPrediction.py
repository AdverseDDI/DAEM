from matplotlib import pyplot  
import scipy as sp  
import numpy as np  
import pandas as pd
from matplotlib import pylab  
from sklearn.datasets import load_files
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import  CountVectorizer  
from sklearn.feature_extraction.text import  TfidfVectorizer  
from sklearn.naive_bayes import MultinomialNB  
from sklearn.metrics import precision_recall_curve, roc_curve, auc  
from sklearn.metrics import classification_report,average_precision_score
from sklearn.linear_model import LogisticRegression  
import time 
from scipy.linalg.misc import norm
from numpy import *
import os
from sklearn.metrics import roc_auc_score, roc_curve, auc 
from sklearn import metrics
import torch
from torch.autograd import Variable
from torch import nn, optim
from torch.utils.data import DataLoader
# from torchvision.utils import save_image
torch.set_printoptions(threshold=np.inf) 

mydevice = torch.device("cuda:1" if torch.cuda.is_available() else "cpu")
print(mydevice)

DrugNum=555
DrugNum=555
# AdverseInteractionNum=1318
AdverseInteractionNum=1318

class AdverseDrugs(object):
	"""docstring for AdverseDrugs"""
	def __init__(self, Drug1,Drug2,AdverseInteraction):
		self.Drug1 = Drug1
		self.Drug2 = Drug2
		self.AdverseInteraction = AdverseInteraction

def LoadData(ADDITensorAddr,EncodeStructureAddr,EncodeSideEffectAddr):
	ADDITensor=[]
	EncodeStructure=[]
	EncodeSideEffect=[]
	for i in range(DrugNum):
		First=[]
		for j in range(DrugNum):
			Second=[]
			for k in range(AdverseInteractionNum):
				Second.append(0)
			First.append(Second)
		ADDITensor.append(First)
	ADDITensor=np.array(ADDITensor)
	ADDITensor=torch.from_numpy(ADDITensor)

	fileIn=open(ADDITensorAddr)
	line=fileIn.readline()
	while line:
		lineArr=line.strip().split('\t')
		lineArr[0]=int(lineArr[0])
		lineArr[1]=int(lineArr[1])
		lineArr[2]=int(lineArr[2])
		if lineArr[2]>=AdverseInteractionNum or lineArr[0]>=DrugNum or lineArr[1]>=DrugNum:
			line=fileIn.readline()
			continue
		# AdverseElt=AdverseDrugs(lineArr[0],lineArr[1],lineArr[2])
		# AdverseSet.append(AdverseElt)
		ADDITensor[lineArr[0],lineArr[1],lineArr[2]]=1.0
		ADDITensor[lineArr[1],lineArr[0],lineArr[2]]=1.0
		line=fileIn.readline()
	ADDITensor=ADDITensor.type(torch.FloatTensor)
	print(ADDITensor.size())

	fileIn=open(EncodeStructureAddr)
	line=fileIn.readline()
	while line:
		lineArr=line.strip().split('\t')
		Structure=lineArr[0].strip().split(' ')
		temp=[]
		for i in Structure:
			temp.append(float(i))
		EncodeStructure.append(temp)
		line=fileIn.readline()
	EncodeStructure=np.mat(EncodeStructure)
	EncodeStructure=torch.from_numpy(EncodeStructure)
	EncodeStructure=EncodeStructure.type(torch.FloatTensor)


	fileIn=open(EncodeSideEffectAddr)
	line=fileIn.readline()
	while line:
		lineArr=line.strip().split('\t')
		SideEffect=lineArr[0].strip().split(' ')
		temp=[]
		for i in SideEffect:
			temp.append(float(i))
		EncodeSideEffect.append(temp)
		line=fileIn.readline()
	EncodeSideEffect=np.mat(EncodeSideEffect)
	EncodeSideEffect=torch.from_numpy(EncodeSideEffect)
	EncodeSideEffect=EncodeSideEffect.type(torch.FloatTensor)

	EncodeStructureSideEffect=torch.cat((EncodeStructure,EncodeSideEffect),1)
	EncodeStructureSideEffect=EncodeStructureSideEffect.type(torch.FloatTensor)
	print(EncodeStructureSideEffect.size())
	# print(EncodeStructureSideEffect[0])
	if torch.cuda.is_available():
		ADDITensor.cuda()
		EncodeStructureSideEffect.cuda()
	return ADDITensor,EncodeStructureSideEffect

def TensorDiag(TensorValue):
	TensorSize=list(TensorValue.size())[0]
	Vector=torch.zeros(TensorSize)
	for i in range(TensorSize):
		Vector[i]=TensorValue[i,i]
	Vector=Vector.type(torch.FloatTensor)
	return Vector
def LearningProcess(opts,ADDITensor,EncodeStructureSideEffect):
	L_value=opts['L_value']
	Alpha=opts['Alpha']
	EPOCH=opts['EPOCH']
	lr=opts['lr']

	Num_StructureSideEffect=list(EncodeStructureSideEffect.size())[1]
	Num_Drug=list(ADDITensor.size())[0]
	Num_ADDI=list(ADDITensor.size())[2]
	print(Num_Drug,Num_ADDI,Num_StructureSideEffect)

	A_Tensor=torch.rand(L_value,Num_StructureSideEffect)
	B_Tensor=torch.rand(L_value,Num_ADDI)
	if torch.cuda.is_available():
		A_Tensor.cuda()
		B_Tensor.cuda()
	for epoch in range(EPOCH):
		for Drug1 in range(Num_Drug):
			for Drug2 in range(Num_Drug):
				for ADDI in range(Num_ADDI):
					f_ijk=0
					for L in range(L_value):
						f_ijk+=A_Tensor[L].reshape(1,Num_StructureSideEffect).mm(
							EncodeStructureSideEffect[Drug1].reshape(Num_StructureSideEffect,1))*\
							A_Tensor[L].reshape(1,Num_StructureSideEffect).mm(
								EncodeStructureSideEffect[Drug2].reshape(Num_StructureSideEffect,1))*\
								B_Tensor[L,ADDI]
					R_ijk=1.0/(1.0+torch.exp(-f_ijk))
					# A_TensorL_Decent=(R_ijk-ADDITensor[Drug1,Drug2,ADDI])*\
					# 	(A_Tensor[L].reshape(1,Num_StructureSideEffect).mm(
					# 		EncodeStructureSideEffect[Drug2].reshape(Num_StructureSideEffect,1))*\
					# 		B_Tensor[L,ADDI]*EncodeStructureSideEffect[Drug1].reshape(1,Num_StructureSideEffect)+\
					# 		A_Tensor[L].reshape(1,Num_StructureSideEffect).mm(
					# 			EncodeStructureSideEffect[Drug1].reshape(Num_StructureSideEffect,1))*\
					# 		B_Tensor[L,ADDI]*EncodeStructureSideEffect[Drug2].reshape(1,Num_StructureSideEffect))+\
					# 		Alpha*A_Tensor[L].reshape(1,Num_StructureSideEffect)
					Temp_Decent1=A_Tensor.mm(EncodeStructureSideEffect[Drug2].reshape(Num_StructureSideEffect,1))
					Temp_Decent2=B_Tensor[:,ADDI].reshape(1,L_value)
					Temp_Decent3=Temp_Decent1.mm(Temp_Decent2)
					Temp_Decent3=TensorDiag(Temp_Decent3)
					Decent1=Temp_Decent3.reshape(L_value,1).mm(
						EncodeStructureSideEffect[Drug1].reshape(1,Num_StructureSideEffect))

					Temp_Decent1=A_Tensor.mm(EncodeStructureSideEffect[Drug1].reshape(Num_StructureSideEffect,1))
					Temp_Decent2=B_Tensor[:,ADDI].reshape(1,L_value)
					Temp_Decent3=Temp_Decent1.mm(Temp_Decent2)
					Temp_Decent3=TensorDiag(Temp_Decent3)
					Decent2=Temp_Decent3.reshape(L_value,1).mm(
						EncodeStructureSideEffect[Drug2].reshape(1,Num_StructureSideEffect))

					A_Tensor_Decent=(R_ijk-ADDITensor[Drug1,Drug2,ADDI])*(Decent1+Decent2)+Alpha*A_Tensor
					A_Tensor=A_Tensor-lr*A_Tensor_Decent


					Temp_Decent1=A_Tensor.mm(EncodeStructureSideEffect[Drug1].reshape(Num_StructureSideEffect,1))
					Temp_Decent2=EncodeStructureSideEffect[Drug2].reshape(1,Num_StructureSideEffect).mm(A_Tensor.transpose(0,1))
					Temp_Decent3=Temp_Decent1.mm(Temp_Decent2)
					Temp_Decent3=TensorDiag(Temp_Decent3)
					E_K=torch.zeros(Num_ADDI)
					E_K=E_K.type(torch.FloatTensor)
					E_K[ADDI]=1.0
					Decent=Temp_Decent3.reshape(L_value,1).mm(E_K.reshape(1,Num_ADDI))
					B_Tensor_Decent=(R_ijk-ADDITensor[Drug1,Drug2,ADDI])*Decent+Alpha*B_Tensor

					B_Tensor=B_Tensor-lr*B_Tensor_Decent

		print(epoch)
	return A_Tensor,B_Tensor

if __name__ == '__main__':

	ADDITensorAddr='AdverseInteractionTensor.txt'
	EncodeStructureAddr='LowDimensionalMolecularStructureRepresentation.txt'
	EncodeSideEffectAddr='LowDimensionalSideEffectRepresentation.txt'
	ADDITensor,EncodeStructureSideEffect=LoadData(
		ADDITensorAddr,EncodeStructureAddr,EncodeSideEffectAddr)
	if torch.cuda.is_available():
		ADDITensor.cuda()
		EncodeStructureSideEffect.cuda()
	lr = 1e-5
	EPOCH = 100

	Num_Drug=list(ADDITensor.size())[0]
	Num_ADDI=list(ADDITensor.size())[2]
	Num_EncodeStructureSideEffect=list(EncodeStructureSideEffect.size())[1]
	

	L_Array=[5,10,15,20,25,30,35,40,45,50]
	L_Array=[5,10,15,20,25,30,35,40,45,50]
	Alpha_Array=[0.001,0.01,0.05,0.1,0.5,1,5,10,100,500,1000]


	fileOut=open('Parameter.txt','a')
	for L_value in L_Array:
		for Alpha in Alpha_Array:
			opts={'L_value':L_value,'Alpha':Alpha,'EPOCH':EPOCH,'lr':lr}
			if os.path.exists('Parameter/'+'L_value'+str(L_value)+'Alpha'+str(Alpha)
				+'.txt'):
				continue
			A_Tensor, B_Tensor=LearningProcess(opts,ADDITensor,EncodeStructureSideEffect)
			tp=0
			fp=0
			tn=0
			fn=0
			ADDIKnown=[]
			ADDIPredict=[]
			for Drug1 in range(Num_Drug):
				for Drug2 in range(Num_Drug):
					for ADDI in range(Num_ADDI):
						f_ijk=0
						for L in range(L_value):
							f_ijk+=A_Tensor[L].reshape(1,Num_EncodeStructureSideEffect).mm(
								EncodeStructureSideEffect[Drug1].reshape(Num_EncodeStructureSideEffect,1))*\
								A_Tensor[L].reshape(1,Num_EncodeStructureSideEffect).mm(
									EncodeStructureSideEffect[Drug2].reshape(Num_EncodeStructureSideEffect,1))*\
									B_Tensor[L,ADDI]
						Pre_f_ijk=1.0/(1.0+torch.exp(f_ijk))
						# print(Pre_f_ijk)
						if Pre_f_ijk>=0.50:
							ADDIPredict.append(1)
							Pre_f_ijk=1
						else:
							ADDIPredict.append(0)
							Pre_f_ijk=0
						ADDIKnown.append(int(ADDITensor[Drug1,Drug2,ADDI].item()))
						if int(ADDITensor[Drug1,Drug2,ADDI].item())==1 and Pre_f_ijk==1:
							tp+=1
							## print('********') 
						elif int(ADDITensor[Drug1,Drug2,ADDI].item())==1 and Pre_f_ijk==0:
							fn+=1
						elif int(ADDITensor[Drug1,Drug2,ADDI].item())==0 and Pre_f_ijk==1:
							fp+=1
						elif int(ADDITensor[Drug1,Drug2,ADDI].item())==0 and Pre_f_ijk==0:
							tn+=1
			sp=tn/(tn+fp)
			acc=(tp+tn)/(tp+tn+fp+fn)
			precision=tp/(tp+fp)
			recall=tp/(tp+fn)
			f_score=2*precision*recall/(precision+recall)

			auc = roc_auc_score(ADDIKnown,ADDIPredict)
			aupr =  average_precision_score(ADDIKnown,ADDIPredict)
			print('L_value=%f, Alpha=%f,sp=%f,acc=%f,precision=%f,recall=%f,f_score=%f,auc=%f,aupr=%f' %(L_value,Alpha,sp,acc,
				precision,recall,f_score,auc,aupr))
			print('L_value=%f, Alpha=%f,sp=%f,acc=%f,precision=%f,recall=%f,f_score=%f,auc=%f,aupr=%f' %(L_value,Alpha,sp,acc,
				precision,recall,f_score,auc,aupr), file=fileOut)
	fileOut.close()
